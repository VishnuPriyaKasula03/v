package com.main.service;


import java.util.List;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.Teacher;
import com.main.model.TimeTable;

public interface TeacherService {

	public void saveTimetable(TimeTable timetable);
	
	public void saveEnotes(Enotes enotes);
	
	public void saveFee(Fee fee);
	
	List<Teacher> fetchTeacherList();

	
	
	
	
	

}
