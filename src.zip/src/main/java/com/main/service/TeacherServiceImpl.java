package com.main.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.StudentDao;
import com.main.dao.TeacherDao;
import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.Teacher;
import com.main.model.TimeTable;

@Service
@Transactional
public class TeacherServiceImpl implements TeacherService {

	private static Logger log = Logger.getLogger(TeacherServiceImpl.class);
	@Autowired
	private TeacherDao teacherdao;

	

	@Override
	public void saveTimetable(TimeTable timetable) {
		log.info("Passing Timetable Information to Dao Layer from Service Layer");
		teacherdao.saveTimetable(timetable);
	}



	@Override
	public List<Teacher> fetchTeacherList() {
		
		return teacherdao.fetchTeacherList();
	}



	@Override
	public void saveEnotes(Enotes enotes) {
		
		teacherdao.saveEnotes(enotes);
	}



	@Override
	public void saveFee(Fee fee) {
		teacherdao.saveFee(fee);
	}

}
