package com.main.dao;

import java.util.List;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.Teacher;
import com.main.model.TimeTable;

/**
 * @author chennareddy.gooli
 *
 *         This PhysicianDao interface is the one which provides methods for
 *         PhysicianDao class for performing operations on Database.
 */
public interface TeacherDao {

	
	void saveTimetable(TimeTable timetable);
	
	List<Teacher> fetchTeacherList();

	void saveEnotes(Enotes enotes);

	void saveFee(Fee fee);
}
