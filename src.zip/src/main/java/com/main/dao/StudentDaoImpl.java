package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.TimeTable;

/**
 * @author chennareddy.gooli
 * 
 *         This PhysicianDao Will be providing the implementation for various
 *         database operations by using both SQL and HQL queries.
 */
@Repository
public class StudentDaoImpl implements StudentDao {

	Student currentStudent;
	
	private static Logger log = Logger.getLogger(StudentDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveStudent(Student student) {
		log.info("Inside saveStudent Method of Dao layer");
		sessionFactory.getCurrentSession().save(student);
	}

	@Override
	public List<Student> fetchStudentList() {
		log.info("Inside fetchStudentList Method of Dao layer");
		List<Student> list  = sessionFactory.getCurrentSession().createQuery("from Student").list();
		return list;
	}

	@Override
	public List<TimeTable> fetchTimeTableList(String standard) {
		System.out.println("Tt"+standard);
		Query query = sessionFactory.getCurrentSession().createQuery("from TimeTable T where T.standard=:tstandard");
		query.setParameter("tstandard",standard);
		List<TimeTable> list = query.list();
		return list;
	}

	@Override
	public List<Enotes> fetchEnotesList(String standard) {
		System.out.println(standard);
		Query query = sessionFactory.getCurrentSession().createQuery("from Enotes E where E.standard=:estandard");
		query.setParameter("estandard",standard);
		List<Enotes> list = query.list();
		return list;
	}
	@Override
	public List<Fee> fetchFeeList(Integer studentId) {
		System.out.println(studentId);
		Query query = sessionFactory.getCurrentSession().createQuery("from Fee F where F.studentId=:fstudentId");
		query.setParameter("fstudentId",studentId);
		List<Fee> list = query.list();
		return list;
	}

	
	
	
}
