package com.main.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.Teacher;
import com.main.model.TimeTable;

/**
 * @author chennareddy.gooli
 * 
 *         This PhysicianDao Will be providing the implementation for various
 *         database operations by using both SQL and HQL queries.
 */
@Repository
public class TeacherDaoImpl implements TeacherDao {

	private static Logger log = Logger.getLogger(TeacherDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void saveTimetable(TimeTable timetable) {
		sessionFactory.getCurrentSession().save(timetable);
	
		
	}

	@Override
	public List<Teacher> fetchTeacherList() {
		List<Teacher> list  = sessionFactory.getCurrentSession().createQuery("from Teacher").list();
		return list;
	}

	@Override
	public void saveEnotes(Enotes enotes) {
		sessionFactory.getCurrentSession().save(enotes);
		
		
	}

	@Override
	public void saveFee(Fee fee) {
		sessionFactory.getCurrentSession().save(fee);
		
	}

	
}
