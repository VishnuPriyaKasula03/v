package com.main.dao;

import java.util.List;

import com.main.model.Enotes;
import com.main.model.Fee;
import com.main.model.Student;
import com.main.model.TimeTable;

/**
 * @author chennareddy.gooli
 *
 *         This PhysicianDao interface is the one which provides methods for
 *         PhysicianDao class for performing operations on Database.
 */
public interface StudentDao {

	void saveStudent(Student student);
	
	List<Student> fetchStudentList();
	
	List<TimeTable> fetchTimeTableList(String standard);
	
	List<Enotes> fetchEnotesList(String standard);

	List<Fee> fetchFeeList(Integer studentId);
	

}
